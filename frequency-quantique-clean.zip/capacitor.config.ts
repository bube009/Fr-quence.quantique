export default {
  appId: 'com.example.frequencyquantique',
  appName: 'frequency-quantique',
  webDir: 'www',
  bundledWebRuntime: false
};
