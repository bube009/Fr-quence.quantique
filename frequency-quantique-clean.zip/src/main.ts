import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
console.log('App started');